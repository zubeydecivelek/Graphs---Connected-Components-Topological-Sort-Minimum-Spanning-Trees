public interface Constants {
    public static final Double SUBSPACE_COMMUNICATION_CONSTANT = 144.5d;
}
